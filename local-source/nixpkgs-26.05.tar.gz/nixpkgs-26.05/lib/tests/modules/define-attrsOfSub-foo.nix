{
  attrsOfSub.foo = { };
}
