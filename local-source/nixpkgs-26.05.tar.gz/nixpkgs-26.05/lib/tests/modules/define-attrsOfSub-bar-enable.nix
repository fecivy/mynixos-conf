{
  attrsOfSub.bar.enable = true;
}
