{
  attrsOfSub.bar = { };
}
