{
  attrsOfSub.foo.enable = true;
}
