{
  imports = [
    ../declare-enable.nix
  ];
}
