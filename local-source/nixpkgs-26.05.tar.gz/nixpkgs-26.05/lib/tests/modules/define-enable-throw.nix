{
  config.enable = throw "oops";
}
