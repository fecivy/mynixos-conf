{
  _class = "nixos";
  config = { };
}
