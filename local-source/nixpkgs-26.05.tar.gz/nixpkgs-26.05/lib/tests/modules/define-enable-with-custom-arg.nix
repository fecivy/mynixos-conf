{ custom, ... }:

{
  config = {
    enable = custom;
  };
}
