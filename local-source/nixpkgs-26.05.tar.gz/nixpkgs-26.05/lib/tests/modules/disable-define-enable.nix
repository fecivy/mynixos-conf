{ ... }:

{
  disabledModules = [ ./define-enable.nix ];
}
