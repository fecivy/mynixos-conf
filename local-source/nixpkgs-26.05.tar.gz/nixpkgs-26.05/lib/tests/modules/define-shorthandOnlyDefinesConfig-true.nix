{ shorthandOnlyDefinesConfig = true; }
