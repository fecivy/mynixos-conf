{
  config.enable = abort "oops";
}
