{

  disabledModules = [
    ./foo.nix
  ];

}
