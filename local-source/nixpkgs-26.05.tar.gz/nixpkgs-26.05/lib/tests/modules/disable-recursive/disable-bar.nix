{

  disabledModules = [
    ./bar.nix
  ];

}
