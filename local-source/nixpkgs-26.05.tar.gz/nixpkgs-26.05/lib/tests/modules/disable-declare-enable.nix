{ ... }:

{
  disabledModules = [ ./declare-enable.nix ];
}
